


function Header () {

    //console.log(props.titulo);
    return (
        <div style={{textAlign:"center"}} className="text-center bg-warning" >
        <br />
        <h1>useEffect</h1>

        <br />
       
        </div>
        
    )
}

export default Header