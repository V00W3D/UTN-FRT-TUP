

export const Footer = () => {

    // console.log(Alumno);

    // const {legajo,nombre,apellido,edad,sexo} = Alumno
    return (
        <div className="footer">

            <h3 className="text-blue-500 text-center bg-warning">FR UTN 2025</h3>
            
        </div>
    )
}

