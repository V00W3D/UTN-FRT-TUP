import React from 'react'

const Componente1 = () => {

    console.log("montado COMP 1");
  return (
    <div>
        <br />
        <h3>componente 1 </h3>
    </div>
  )
}

export default Componente1