export const lengProg = [{
    id:1,
    nombre:"javascript",
    descripcion:"lenguaje semiduro",
    imagen:"link imagen",
    tipo:""
},{
    
}]