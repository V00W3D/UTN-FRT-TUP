
ciclo de vida de una persona

nace
crece
reproduce
muere


ciclo de vida del componente

nace (montaje)
crece (actualizando creciendo)
reproduce (reutiizo)
muere (desmonta)

//compp clases
componnetdidmount()
componentdidupdate()


useEffect -> solucionar los problemas de re renderizacion

tiene 2partes 
1ra callback donde pondre el efecto sec que necesito
2da array de dependencias

si el array esta vacio significa que el efecto se ejecutara 1 sola vez