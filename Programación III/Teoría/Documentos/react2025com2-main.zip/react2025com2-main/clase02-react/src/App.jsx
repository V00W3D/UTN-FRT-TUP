import {Hijo1} from "./Hijo1"

import Header from "./Header"
import Footer from "./Footer"
import Aside from "./Aside"

function App() {
 


 

  return (
    <>
      
      <Header/>
      <Aside/>
      
      <Footer/>
    </>
  )
}

export default App
