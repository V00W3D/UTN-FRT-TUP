import React from 'react'

export const Hijo1 = () => {
  return (
    <div>Hijo1</div>
  )
}

//export default Hijo1