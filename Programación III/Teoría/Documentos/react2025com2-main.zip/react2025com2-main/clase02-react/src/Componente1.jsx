

function Componente1() {
    return (
        <h3>soy el componente 1</h3>)
}
export default Componente1;