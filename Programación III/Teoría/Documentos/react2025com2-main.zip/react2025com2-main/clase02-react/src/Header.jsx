const Header = () => {
    return (
        <div className="" style={{backgroundColor:"blue",textAlign:"center"}}>
            <br />
            <h1>Bienvenidos alumnos a React</h1>
            <br />
            <h3>Aprendiendo React js</h3>
            <br />
            <hr />
        </div>

    );
}

export default Header;