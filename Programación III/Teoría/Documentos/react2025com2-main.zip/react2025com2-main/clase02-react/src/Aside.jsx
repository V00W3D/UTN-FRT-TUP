import React from 'react'
import { Hijo1 } from './Hijo1'


const Aside = () => {



     let nombre = "agustina"



    //codigo js

  return (
    <div style={{backgroundColor:"green"}}>
        <br />
      <h3>suma de 2+6 ={2 + 6}</h3>
      <br />
      <p>nombre: {nombre}</p>
    <br />
    <Hijo1/>
    </div>
  )
}

export default Aside