const Saludar = () => {
    return (
        <div>
            <br />
            <h1>Bienvenidos a React Alumnos de la com 2</h1><br />
        </div>
    )
}

export default Saludar