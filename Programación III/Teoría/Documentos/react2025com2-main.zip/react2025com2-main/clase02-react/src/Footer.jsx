import React from 'react'
import "./Footer.css"

const Footer = () => {
    return (
        <div className="footer">
            <hr />
            <br />
            <h4 className='h4'>FRT UTN 2025</h4>
            <br />
        </div>

    )
}

export default Footer