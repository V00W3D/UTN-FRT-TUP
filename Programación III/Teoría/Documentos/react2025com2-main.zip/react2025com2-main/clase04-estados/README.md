# clase 04 - Estados

componente -> funcion que si o si me debe retornar html o jsx 


useState -> hook (gancho o engancharse) -> funcion especial que sirve para solucionar determinado peoblema 

useState -> es una funcion que devuelve un vector o array con 2 posiciones 
1ra -> valor inicial
2da -> funcion para cambiar ese valor inicial

ciclo de vida del componente

nace -> montando 
crece -> actualizando
reproduce -> reutilizo
muere -> desmonta
