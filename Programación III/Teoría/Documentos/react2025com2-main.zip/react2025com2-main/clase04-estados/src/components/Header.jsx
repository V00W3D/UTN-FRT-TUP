import React from 'react'

const Header = () => {
    return (
        <div className='bg-warning'>
            <br />
            <h1>Estados</h1>
            <br />
        </div>
    )
}

export default Header