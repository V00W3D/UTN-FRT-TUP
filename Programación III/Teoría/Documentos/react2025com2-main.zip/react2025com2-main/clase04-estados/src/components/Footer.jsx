import React from 'react'

const Footer = () => {
  return (
    <div className='bg-success'>
        <br />
        <h3>FRT UTN 2025</h3>
        <br />
    </div>
  )
}

export default Footer