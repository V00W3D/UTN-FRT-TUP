import React from 'react'
import Nieto2 from './Nieto2'
import Nieto1 from './Nieto1'

const Hijo1 = () => {
  return (
    <div>
        <Nieto1 />
        <Nieto2 />
    </div>
  )
}

export default Hijo1