import React from 'react'
import Nieto3 from './Nieto3'
import Nieto4 from './Nieto4'

const Hijo2 = () => {
  return (
    <div>
        <Nieto3 />
        <Nieto4 />
    </div>
  )
}

export default Hijo2