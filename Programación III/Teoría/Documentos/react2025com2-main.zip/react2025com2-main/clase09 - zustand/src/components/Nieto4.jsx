import React from 'react'
import Bisnieto2 from './Bisnieto2'

const Nieto4 = () => {
  return (
    <div><Bisnieto2 /></div>
  )
}

export default Nieto4