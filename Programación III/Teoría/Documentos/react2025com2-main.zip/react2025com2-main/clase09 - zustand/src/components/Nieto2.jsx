import React from 'react'
import Bisnieto1 from './Bisnieto1'

const Nieto2 = ({data}) => {
  return (
    <div><Bisnieto1 data={data}/></div>
  )
}

export default Nieto2