CRA(create react app)
Vite (create vite@latest)
npm (node package manager)

npm create vite@latest -> creacion del proyecto react
me pide el nombre del proyecto
me pide el framework -> React
el llenguaje -> JavaScript

cd nombreProyecto
npm i 
npm run dev -> corre mi proyecto en el puerto 5173

Problemas de SCRIPT

Get -ExecutionPolicy

Set-executionpolicy remotesigned
Set -ExecutionPolicy Unrestricted


SPA(single page aplication)


babel + webpack -> transpilador 


React -> UI (user interface) UX



scripts ejecutables de mi app

Componenets React -> Funcion que me devuelve codigo js + HTML o HTML solo


JSX -> mezcla de HTML + JS

Import -> traer archivos o librerias etc de otro lugar

Export -> enviar o sacar archivos o librerias etc de mi proyecto a otro lugar

snippets -> atajos React simple snippets es7 snippets
rafce - sfc- rfce 

componente tiene 4 partes visibles


1 - IMPORT 
2 - FUNCION(arriba del retrun y abajo del return)
3 - EXPORT


