import React from 'react'
import Navigation from './Navigation'

const Header = () => {
  return (
    <div>
        <br />
        <h1>React-Router-Dom</h1>
        <br />
        <Navigation/>

    </div>
  )
}

export default Header