import React from 'react'

const Error = () => {
  return (
    <div>
        <br />
        <img src="https://http.cat/images/404.jpg" alt="" />
        <br />
        <p>pagina no encontrada</p>
        <br />
        <a href="/">volver a inicio</a>
    </div>
  )
}

export default Error