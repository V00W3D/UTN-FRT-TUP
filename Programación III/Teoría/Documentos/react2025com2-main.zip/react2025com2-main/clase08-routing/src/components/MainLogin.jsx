import React from 'react'

const MainLogin = () => {
  return (
    <div>MainLogin</div>
  )
}

export default MainLogin