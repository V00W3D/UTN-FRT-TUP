import React from 'react'

const MainRegister = () => {
  return (
    <div>MainRegister</div>
  )
}

export default MainRegister