document.getElementById("bloque").innerHTML = "<h3>hola alumnos de la com 2</h3>"


function sumar (a,b){
    let suma = a+b
    return suma

    return []

}


