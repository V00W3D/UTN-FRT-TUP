


const Header = () => {

    

  return (
    <div className='bg-info'>
        <br />
       <h3>CRUD 2025</h3>

        <br />
    </div>
  )
}

export default Header