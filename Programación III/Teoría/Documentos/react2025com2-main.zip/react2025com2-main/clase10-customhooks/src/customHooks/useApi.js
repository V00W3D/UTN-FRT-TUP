


const useApi = () =>{

    const getProductos = () =>{

    }

    const singleProduct = () =>{

    }

    const removeProduct

}