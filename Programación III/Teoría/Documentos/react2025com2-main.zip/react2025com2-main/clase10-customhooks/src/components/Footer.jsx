import React from 'react'

const Footer = () => {
  return (
    <div className='bg-info'>Footer</div>
  )
}

export default Footer