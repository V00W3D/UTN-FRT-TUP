import React from 'react'

const MainPersonaje = () => {
  return (
    <div>MainPersonaje</div>
  )
}

export default MainPersonaje